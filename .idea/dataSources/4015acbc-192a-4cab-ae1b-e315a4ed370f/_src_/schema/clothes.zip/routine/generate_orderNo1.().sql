CREATE PROCEDURE generate_orderNo1()
  BEGIN
  DECLARE currentDate VARCHAR(15);
  DECLARE maxNo INT DEFAULT 0; 
  DECLARE oldOrderNo VARCHAR(25)  DEFAULT '';   
  DECLARE newOrderNo VARCHAR(25)  DEFAULT '';  
  
    SELECT DATE_FORMAT(NOW(), '%Y%m%d') INTO currentDate ;-- 订单编号形式:前缀+年月日+流水号，如：SH2013011000002   
 
    
  SELECT IFNULL(soid, '') INTO oldOrderNo   
  FROM stockout   
  WHERE SUBSTRING(soid, 3, 8) = currentDate   
    AND SUBSTRING(soid, 1, 2) = 'ck'   
    and length(soid) = 7 + 8  
  ORDER BY soid DESC LIMIT 1 ; -- 有多条时只显示离现在最近的一条   
    
  IF oldOrderNo != '' THEN   
    SET maxNo = CONVERT(SUBSTRING(oldOrderNo, -5), DECIMAL) ;-- SUBSTRING(oldOrderNo, -5)：订单编号如果不为‘‘截取订单的最后5位   
  END IF ;  
  SELECT   
    CONCAT('ck', currentDate,  LPAD((maxNo + 1), 5, '0')) INTO newOrderNo ; -- LPAD((maxNo + 1), 5, '0')：如果不足5位，将用0填充左边   
    
  INSERT INTO stockout (soid,loginName,sotime,sostute ) VALUES (newOrderNo,'hanbon',currentDate,'1' ) ; -- 向订单表中插入数据   
--    set newOrderNo = l_orderNo;   
    

END;
