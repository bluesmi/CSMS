CREATE PROCEDURE generate_orderNo()
  BEGIN
  DECLARE currentDate VARCHAR(15);
  DECLARE maxNo INT DEFAULT 0; 
  DECLARE oldOrderNo VARCHAR(25)  DEFAULT '';
  DECLARE newOrderNo VARCHAR(25)  DEFAULT '';   
    
  /*if num = 8 then   */
    SELECT DATE_FORMAT(NOW(), '%Y%m%d') INTO currentDate ;-- 订单编号形式:前缀+年月日+流水号，如：SH2013011000002   
  /*elseif num = 14 then -- 根据年月日时分秒生成订单编号   
    SELECT DATE_FORMAT(NOW(), '%Y%m%d%H%i%s') INTO currentDate ; -- 订单编号形式：前缀+年月日时分秒+流水号，如：SH2013011010050700001,个人不推荐使用这种方法生成流水号   
  else -- 根据年月日时分生成订单编号   
    SELECT DATE_FORMAT(NOW(), '%Y%m%d%H%i') INTO currentDate ;-- 订单形式：前缀+年月日时分+流水号,如：SH20130110100900005   
  end if ;  */
    
  SELECT IFNULL(sid, '') INTO oldOrderNo   
  FROM stockin   
  WHERE SUBSTRING(sid, 3, 8) = currentDate   
    AND SUBSTRING(sid, 1, 2) = 'rk'   
    and length(sid) = 7 + 8 
  ORDER BY sid DESC LIMIT 1 ; -- 有多条时只显示离现在最近的一条   
    
  IF oldOrderNo != '' THEN   
    SET maxNo = CONVERT(SUBSTRING(oldOrderNo, -5), DECIMAL) ;-- SUBSTRING(oldOrderNo, -5)：订单编号如果不为‘‘截取订单的最后5位   
  END IF ;  
  SELECT   
    CONCAT('rk', currentDate,  LPAD((maxNo + 1), 5, '0')) INTO newOrderNo ; -- LPAD((maxNo + 1), 5, '0')：如果不足5位，将用0填充左边   
    
  INSERT INTO stockin (sid,wid,loginName,stime,sremark,sstute ) VALUES (newOrderNo, '1','hanbon',currentDate,'weqwe','1' ) ; -- 向订单表中插入数据   
--    set newOrderNo = l_orderNo;   
 /* SELECT   
    newOrderNo ;  */

END;
